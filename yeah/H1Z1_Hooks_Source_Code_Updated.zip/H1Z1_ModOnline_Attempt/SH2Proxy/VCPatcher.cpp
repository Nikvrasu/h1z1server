#include "stdafx.h"
#include <iostream>
#include <fstream>
#include "VCPatcher.h"
#include "Hooking.Patterns.h"
#include "Utils.h"
#include <stdio.h>
#include <winternl.h>
#include <ntstatus.h>
#include <windows.h>
#include <tlhelp32.h>
#include <MinHook.h>
#include "UdpPlatformAddress.h"

//FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
#define CONSOLE_ENABLED_THAT_CRASHES

static bool consoleShowing = false;
static float lasttext;

intptr_t* MenuManager = (intptr_t*)0x868638;
void* ConnectionMgrDummy = (void*)0x143B3E498;

#include "timer.h"
#include <iostream>

#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdio.h>
#include <windows.h>
#include <udis86.h>

#pragma comment(lib, "ws2_32.lib")

static bool(*g_origSetupInitialConnection)(intptr_t a1);
static bool(*g_InitGameWorld)(intptr_t a1);
static bool(*g_orig_TrySignalLaunchPadEvent)(intptr_t a1, void* a2);
static bool(*g_RegisterCommands)();
static void(*g_InitCharacterStuff)(intptr_t a1, intptr_t a2, intptr_t a3, intptr_t a4);
static void(*g_BeginZoningAreaWrapper)(intptr_t a1, float possiblyRadius);

void hexDump(const char* desc, const void* addr, const int len);

static void* FindCallFromAddress(void* methodPtr, ud_mnemonic_code mnemonic = UD_Icall, bool breakOnFirst = false)
{
	// return value holder
	void* retval = nullptr;

	// initialize udis86
	ud_t ud;
	ud_init(&ud);

	// set the correct architecture
	ud_set_mode(&ud, 64);

	// set the program counter
	ud_set_pc(&ud, reinterpret_cast<uint64_t>(methodPtr));

	// set the input buffer
	ud_set_input_buffer(&ud, reinterpret_cast<uint8_t*>(methodPtr), INT32_MAX);

	// loop the instructions
	while (true)
	{
		// disassemble the next instruction
		ud_disassemble(&ud);

		// if this is a retn, break from the loop
		if (ud_insn_mnemonic(&ud) == UD_Iint3 || ud_insn_mnemonic(&ud) == UD_Inop)
		{
			break;
		}

		if (ud_insn_mnemonic(&ud) == mnemonic)
		{
			// get the first operand
			auto operand = ud_insn_opr(&ud, 0);

			// if it's a static call...
			if (operand->type == UD_OP_JIMM)
			{
				// ... and there's been no other such call...
				if (retval == nullptr)
				{
					// ... calculate the effective address and store it
					retval = reinterpret_cast<void*>(ud_insn_len(&ud) + ud_insn_off(&ud) + operand->lval.sdword);

					if (breakOnFirst)
					{
						break;
					}
				}
				else
				{
					// return an empty pointer
					retval = nullptr;
					break;
				}
			}
		}
	}

	return retval;
}

intptr_t LaunchPadA1Ptr;
static bool TrySignalLaunchPadEvent(intptr_t a1, void* a2)
{
	LaunchPadA1Ptr = a1;
	//g_origSetupInitialConnection(a1);
	return g_orig_TrySignalLaunchPadEvent(a1, a2);
}

HANDLE h_console;
static void tryAllocConsole() {
	if (!consoleShowing)
	{
		//Allocate a console
		AllocConsole();
		AttachConsole(GetCurrentProcessId());
		freopen("CON", "w", stdout);
		consoleShowing = true;
		h_console = GetStdHandle(STD_OUTPUT_HANDLE);
	}
}

static void doSomeLogging(const char* fmt, va_list args) {
	tryAllocConsole();

	FILE* logFile = _wfopen(L"GameMessages.log", L"a");
	if (logFile)
	{
		char buffer[2048 * 4], bufferNewLine[(2048 * 4) + 1];

		vsnprintf(buffer, sizeof(buffer), fmt, args);
		SetConsoleTextAttribute(h_console, 7);

		sprintf_s(bufferNewLine, "%s\n", buffer);
		vfprintf(logFile, bufferNewLine, args); //write to file

		va_end(args);

		fclose(logFile);
		std::cout << bufferNewLine;
		//printf_s(bufferNewLine);
	}
}

#if 1
void logFuncCustom(intptr_t unka1, const char* logEntry, ...) {

	va_list args;
	va_start(args, logEntry);
	doSomeLogging(logEntry, args);
	va_end(args);

	return;
}
#endif

static void(*logFuncCustom1_orig)(intptr_t a1, intptr_t size, const char* logEntry, ...);
static void logFuncCustom1(intptr_t a1, intptr_t size, const char* logEntry, ...) {

	logFuncCustom1_orig(a1, size, logEntry);

	va_list args;
	va_start(args, logEntry);
	doSomeLogging(logEntry, args);
	va_end(args);

	return;
}

static void(*logFuncCustom2_orig)(int loglevel, intptr_t* unka1, const char* logEntry, va_list args);
static void logFuncCustom2(int loglevel, intptr_t* unka1, const char* logEntry, va_list args) {
	printf("Return Address: %p\n", _ReturnAddress());

	logFuncCustom2_orig(loglevel, unka1, logEntry, args);

	doSomeLogging(logEntry, args);

	return;
}

static void(*logFuncCustom_orig3)(char* a1, char* a2, char* a3, int a4, va_list args);
static void logFuncCustom3(char* a1, char* a2, char* a3, int a4, va_list args) {

	logFuncCustom_orig3(a1, a2, a3, a4, args);

	doSomeLogging(a2, args);
	return;
}

static void(*logFuncCustom4_orig)(intptr_t* unka1, const char* logEntry, va_list args);
static void logFuncCustom4(intptr_t* unka1, const char* logEntry, va_list args) {

	logFuncCustom4_orig(unka1, logEntry, args);
	doSomeLogging(logEntry, args);
	return;
}

enum ClientStates {
	cClientRunStateNone = 0,
	cClientRunStateAdminBackdoorLoginStart = 1,
	cClientRunStateAdminBackdoorLogin,
	cClientRunStateAdminPreInitialize,
	cClientRunStatePreInitialize,
	cClientRunStateVerifyPsnLogin = 6,
	cClientRunStateCheckPsnChatRestrictions,
	cClientRunStateWaitForPsnChatRestrictionsDialog,
	cClientRunStateCheckPsnUgcRestrictions,
	cClientRunStateWaitForPsnUgcRestrictionsDialog,
	cClientRunStateWaitingForPsnLogin,
	cClientRunStateStartingLogin,
	cClientRunStateWaitForCharacterList,
	cClientRunStateWaitForCharacterSelectLoad,
	cClientRunStateCharacterCreateOrDelete,
	cClientRunStateLoggingIn,
	cClientRunStateNetInitialize,
	cClientRunStateConnecting,
	cClientRunStatePostInitialize,
	cClientRunStateWaitForInitialDeployment,
	cClientRunStatePostInitialDeployment,
	cClientRunStateWaitForFirstZone,
	cClientRunStateWaitForConfirmationPacket,
	cClientRunStatePostWaitForFirstZone,
	cClientRunStateWaitForContinue,
	cClientRunStateRunning,
	cClientRunStateWaitForTeleport,
	cClientRunStateWaitForZoneLoad,
	cClientRunStateWaitingForReloginSession,
	cClientRunStateStartingRelogin,
	cClientRunStateVerifyXBLiveLogin = 34,
	cClientRunStateShuttingDown
};

static bool(*g_origRespawnWindow__DisplayRespawn)(intptr_t a1);
static bool RespawnWindow__DisplayRespawn(intptr_t a1)
{
	g_origRespawnWindow__DisplayRespawn(a1);
	return true; //never fail
}

static void(*g_origShowErrorCodeAndExitImmediately)(int code, char* reason, bool a3, bool* a4);
static void ShowErrorCodeAndExitImmediately(int code, char* reason, bool a3, bool* a4)
{
	if (code == 8) return;

	g_origShowErrorCodeAndExitImmediately(code, reason, a3, a4);
}

static void* (*g_origAllocSomeMemory)(int size);
static void* (*g_instanceUnknownClass)(void* a1);
void* unk_143B3E5B8 = (void*)0x143B3E5B8;
void* g_proxiedCharacter = (void*)0x143B3E438;

std::atomic<bool> alreadyDoneDeployment = false;
std::atomic<bool> waitingForZoneLoad = true;

bool alreadyDone = false;
static void(*g_origLoadConfigFile)(intptr_t a1, bool a2);
static void(*g_origOnGameStartup)(intptr_t a1);
static void OnGameStartup(intptr_t a1)
{
	int switchCaseReason = *(int*)(a1 + 0x202208);
	int switchCaseReason2 = *(int*)(a1 + 0x315E0);

	//attickminimalrendering workaround
	*(intptr_t*)(a1 + 0x231873) = 1; //render timer related thing, set to 1
	*(intptr_t*)(a1 + 0x389C1) = 1; //render timer related thing, set to 1

	if (switchCaseReason == 0 || switchCaseReason2 == 0)
	{
		if (!alreadyDone)
			*(int*)(a1 + 0x315E0) = cClientRunStatePreInitialize;//4; //skip login

		alreadyDone = true;
	}

	g_origOnGameStartup(a1);
	return;
}

static char* (*g_origGetShutdownReasonString)(int index);
static char* GetShutdownReasonString(int index)
{
	char* string = g_origGetShutdownReasonString(index);
	logFuncCustom(0, "(%d), %s", index, string);
	return string; //index is 6 when it fails which is assigned by shutdown (35)
}

static void(*g_orig_SetupAuthData)(intptr_t a1);
static void SetupAuthData(intptr_t a1)
{
	*(intptr_t*)(a1 + 0x31B68) = 0; //feed it a bunch of lies
	*(intptr_t*)(a1 + 0x31F20) = 0;
	*(intptr_t*)(a1 + 0x31F21) = 0;

	g_orig_SetupAuthData(a1);
	return;
}

#ifdef CONSOLE_ENABLED_THAT_CRASHES
static HookFunction hookFunction([]()
	{
	});
#endif

bool ReturnTrue() {
	return true;
}
bool ReturnFalse() {
	return false;
}
extern VCPatcher gl_patcher;

static bool(*g_origConstructDisplay)(intptr_t a1);
static bool ConstructDisplay(intptr_t a1)
{
	g_origConstructDisplay(a1);
	return true; //never fail
}

static bool(*g_origOnReceiveServer)(void* a1, void* a2, void* a3);
static bool OnReceiveServer(void* a1, void* a2, void* a3)
{
	return g_origOnReceiveServer(a1, a2, a3);
}

static SOCKET g_gameSocket;

std::string string_to_hex(const std::string& input)
{
	static const char* const lut = "0123456789ABCDEF";
	size_t len = input.length();

	std::string output;
	output.reserve(2 * len);
	for (size_t i = 0; i < len; ++i)
	{
		const unsigned char c = input[i];
		output.push_back(lut[c >> 4]);
		output.push_back(lut[c & 15]);
	}
	return output;
}

int __stdcall CfxBind(SOCKET s, sockaddr* addr, int addrlen)
{
	sockaddr_in* addrIn = (sockaddr_in*)addr;

	printf_s("binder on %i is %p, %p\n", htons(addrIn->sin_port), (void*)s, _ReturnAddress());

	//if (htons(addrIn->sin_port) == 34567)
	{
		g_gameSocket = s;
	}

	return bind(s, addr, addrlen);
}

int __stdcall CfxRecvFrom(SOCKET s, char* buf, int len, int flags, sockaddr* from, int* fromlen)
{
	static char buffer[65536];
	uint16_t netID = 0;
	sockaddr_in* outFrom = (sockaddr_in*)from;
	char addr[60];
	if (s == g_gameSocket)
	{
		inet_ntop(AF_INET, &outFrom->sin_addr.s_addr, addr, sizeof(addr));
		printf_s("CfxRecvFrom (from %i %s) %i bytes on %p, port: %i, %p\n", netID, addr, len, (void*)s, htons(outFrom->sin_port), _ReturnAddress());
	}

	return recvfrom(s, buf, len, flags, from, fromlen);
}

int __stdcall CfxSendTo(SOCKET s, char* buf, int len, int flags, sockaddr* to, int tolen)
{
	sockaddr_in* toIn = (sockaddr_in*)to;

	if (s == g_gameSocket)
	{
		if (toIn->sin_addr.S_un.S_un_b.s_b1 == 0xC0 && toIn->sin_addr.S_un.S_un_b.s_b2 == 0xA8)
		{
			//g_pendSendVar = 0;

			//if (CoreIsDebuggerPresent())
			{
				printf_s("CfxSendTo (to internal address %i) port: %i, %i b (from thread 0x%x), %p\n", (htonl(toIn->sin_addr.s_addr) & 0xFFFF) ^ 0xFEED, htons(toIn->sin_port), len, GetCurrentThreadId(), _ReturnAddress());
				printf_s("CfxSendTo: Data: %s Hex: %s\n", buf, string_to_hex(buf));
			}
		}
		else
		{
			char publicAddr[256];
			inet_ntop(AF_INET, &toIn->sin_addr.s_addr, publicAddr, sizeof(publicAddr));

			if (toIn->sin_addr.s_addr == 0xFFFFFFFF)
			{
				return len;
			}

			printf_s("CfxSendTo (to %s) port: %i, %i b, %p\n", publicAddr, htons(toIn->sin_port), len, _ReturnAddress());
		}

		//g_netLibrary->RoutePacket(buf, len, (uint16_t)((htonl(toIn->sin_addr.s_addr)) & 0xFFFF) ^ 0xFEED);

		//return len;
	}

	return sendto(s, buf, len, flags, to, tolen);
}

int __stdcall CfxSend(SOCKET s, char* buf, int len, int flags)
{

	if (s == g_gameSocket)
	{
		printf_s("CfxSend %i b, %p\n", len, _ReturnAddress());
	}

	return send(s, buf, len, flags);
}

int __stdcall CfxWSAStartup(WORD wVersionRequested, LPWSADATA lpWSAData) {
	return WSAStartup(wVersionRequested, lpWSAData);
}

int __stdcall CfxGetSockName(SOCKET s, struct sockaddr* name, int* namelen)
{
	int retval = getsockname(s, name, namelen);

	sockaddr_in* addrIn = (sockaddr_in*)name;

	if (s == g_gameSocket /*&& wcsstr(GetCommandLine(), L"cl2")*/)
	{
		addrIn->sin_port = htons(6672);
	}

	return retval;
}

static int(__stdcall* g_oldSelect)(int nfds, fd_set* readfds, fd_set* writefds, fd_set* exceptfds, const timeval* timeout);

int __stdcall CfxSelect(_In_ int nfds, _Inout_opt_ fd_set FAR* readfds, _Inout_opt_ fd_set FAR* writefds, _Inout_opt_ fd_set FAR* exceptfds, _In_opt_ const struct timeval FAR* timeout)
{
	bool shouldAddSocket = false;

	for (int i = 0; i < readfds->fd_count; i++)
	{
		if (readfds->fd_array[i] == g_gameSocket)
		{
			memmove(&readfds->fd_array[i + 1], &readfds->fd_array[i], readfds->fd_count - i - 1);
			readfds->fd_count -= 1;
			nfds--;

			/*
			if (g_netLibrary->WaitForRoutedPacket((timeout) ? ((timeout->tv_sec * 1000) + (timeout->tv_usec / 1000)) : INFINITE))
			{
				shouldAddSocket = true;
			}
			*/
		}
	}

	//FD_ZERO(readfds);

	if (nfds > 0)
	{
		nfds = g_oldSelect(nfds, readfds, writefds, exceptfds, timeout);
	}

	if (shouldAddSocket)
	{
		FD_SET(g_gameSocket, readfds);

		nfds += 1;
	}

	return nfds;
}

static void(*logFuncCustomCallOrig_orig)(void* a1, const char* fmt, va_list args);
static void logFuncCustomCallOrig(void* a1, const char* fmt, va_list args) {
	__try
	{
		doSomeLogging(fmt, args);
		logFuncCustomCallOrig_orig(a1, fmt, args);
	}
	__except (EXCEPTION_EXECUTE_HANDLER)
	{
		printf_s("logFuncCustomCallOrig excepted, caught and returned.\n");
	}
}

//ANTI DEBUG
bool IsDebuggerPresentOurs() {
	return true;
}


typedef NTSTATUS(NTAPI* pfnNtQueryInformationProcess)(
	_In_      HANDLE           ProcessHandle,
	_In_      UINT             ProcessInformationClass,
	_Out_     PVOID            ProcessInformation,
	_In_      ULONG            ProcessInformationLength,
	_Out_opt_ PULONG           ReturnLength
	);

int ProcessDebugPort2 = 7;

pfnNtQueryInformationProcess g_origNtQueryInformationProcess = NULL;


static ULONG ValueProcessBreakOnTermination = FALSE;
static bool IsProcessHandleTracingEnabled = false;

DWORD dwExplorerPid = 0;
WCHAR ExplorerProcessName[] = L"explorer.exe";

DWORD GetProcessIdByName(const WCHAR* processName)
{
	HANDLE hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);

	if (hProcessSnap == INVALID_HANDLE_VALUE)
	{
		return 0;
	}

	PROCESSENTRY32 pe32;
	pe32.dwSize = sizeof(PROCESSENTRY32);

	if (!Process32First(hProcessSnap, &pe32))
	{
		CloseHandle(hProcessSnap);
		return 0;
	}

	DWORD pid = 0;

	do
	{
		if (!lstrcmpiW((LPCWSTR)pe32.szExeFile, processName))
		{
			pid = pe32.th32ProcessID;
			break;
		}
	} while (Process32Next(hProcessSnap, &pe32));

	CloseHandle(hProcessSnap);
	return pid;
}

DWORD GetExplorerProcessId()
{
	if (!dwExplorerPid)
	{
		dwExplorerPid = GetProcessIdByName(ExplorerProcessName);
	}
	return dwExplorerPid;
}

void SetupSetPEB() {
	// Thread Environment Block (TEB)
#if defined(_M_X64) // x64
	PTEB tebPtr = reinterpret_cast<PTEB>(__readgsqword(reinterpret_cast<DWORD_PTR>(&static_cast<NT_TIB*>(nullptr)->Self)));
#else // x86
	PTEB tebPtr = reinterpret_cast<PTEB>(__readfsdword(reinterpret_cast<DWORD_PTR>(&static_cast<NT_TIB*>(nullptr)->Self)));
#endif

	// Process Environment Block (PEB)
	PPEB pebPtr = tebPtr->ProcessEnvironmentBlock;
	pebPtr->BeingDebugged = false;
}

static LONG(*g_exceptionHandler)(EXCEPTION_POINTERS*);
static BOOLEAN(*g_origRtlDispatchException)(EXCEPTION_RECORD* record, CONTEXT* context);

static BOOLEAN RtlDispatchExceptionStub(EXCEPTION_RECORD* record, CONTEXT* context)
{
	// anti-anti-anti-anti-debug
	if (IsDebuggerPresentOurs() && (record->ExceptionCode == 0xc0000008/* || record->ExceptionCode == 0xc0000005*/))
	{
		return TRUE;
	}

	BOOLEAN success = g_origRtlDispatchException(record, context);
	//140533ae2
	if (IsDebuggerPresentOurs())
	{
		if (!success) {
			printf("Exception at: %p\n", record->ExceptionAddress);
		}
		return success;
	}

	static bool inExceptionFallback;

	if (!success)
	{
		if (!inExceptionFallback)
		{
			inExceptionFallback = true;

			//AddCrashometry("exception_override", "true");

			EXCEPTION_POINTERS ptrs;
			ptrs.ContextRecord = context;
			ptrs.ExceptionRecord = record;

			if (g_exceptionHandler)
			{
				g_exceptionHandler(&ptrs);
			}

			inExceptionFallback = false;
		}
	}

	return success;
}

void SetupHook()
{
	void* baseAddress = GetProcAddress(GetModuleHandle("ntdll.dll"), "KiUserExceptionDispatcher");

	if (baseAddress)
	{
		void* internalAddress = FindCallFromAddress(baseAddress, UD_Icall, true);

		{
			MH_CreateHook(internalAddress, RtlDispatchExceptionStub, (void**)&g_origRtlDispatchException);
		}
	}

	MH_EnableHook(MH_ALL_HOOKS);
	return;
}

void VCPatcher::PreHooks() {
	SetupSetPEB();
	SetupHook();
}

static void WINAPI ExitProcessReplacement(UINT exitCode)
{
	TerminateProcess(GetCurrentProcess(), exitCode);
}

#if IS_NON_ADMIN_EXE
//showFrameRate(__int64 a1, char a2, __int64 a3, __int64 a4)
//143CC2CD8
void* luaVM = (void*)0x143CC2CD8;
void* unkLuaRel = (void*)0x1421E22F0;
bool* profilerPtr = (bool*)0x142CD9A58;

static hook::cdecl_stub<void(void*, /*LuaVM**/ char* funcName, int, int)> executeLuaFunction([]()
{
	return hook::pattern("48 8D 05 ? ? ? ? 48 89 45 18 45 33 ED 4C 89 6D 20 48 8D 05").count(1).get(0).get<void>(-71);
});

static hook::cdecl_stub<void(void*, /*LuaVM**/ char* funcName)> executeLuaUnk([]()
{
	return hook::pattern("48 89 5C 24 ? 48 89 6C 24 ? 48 8B DA 66 0F 1F 44 00").count(1).get(0).get<void>(-45);
});

static hook::cdecl_stub<void(void*)> doTeleport([]()
{
	return hook::pattern("40 53 48 83 EC 20 48 8D 15 ? ? ? ? 48 8B D9 E8 ? ? ? ? 48 8B 8B ? ? ? ? E8").count(1).get(0).get<void>(0);
});

static hook::cdecl_stub<void(void*, bool zoning, bool forcedLoadingScreen)> BC_WaitForWorldReady([]()
{
	return hook::pattern("40 88 B7 ? ? ? ? 88 9F ? ? ? ? 48 8D 4C 24 ? E8 ? ? ? ? 48 8B").count(1).get(0).get<void>(-173);
});

//EB 0A 0F B6 01 88 47 08 48 FF 42 10 48 8D 57 10 48 8B CB E8 ? ? ? ? 48 8B 4B 10 33 F6 48 8D 41 04 48 3B 43 18 76 11 89 77 28 48 -51

static hook::cdecl_stub<void(void*, char* dataBuf)> parseZoneDetails([]()
{
	return hook::pattern("48 8D 57 10 48 8B CB E8 ? ? ? ? 48 8B 4B 10 33 F6 48 8D 41 04 48 3B 43 18 76 11 89 77 28 48").count(1).get(0).get<void>(-63);
});

static hook::cdecl_stub<void(char* inBuffer, int len, char** outBuffer)> dumpPacket([]()
{
	return hook::pattern("4C 89 44 24 ? 89 54 24 10 48 89 4C 24 ? 53 55 57 48 81 EC").count(1).get(0).get<void>(0);
});

static hook::cdecl_stub<void(void* luaVM, char* searchFilter)> filterDataSource([]()
{
	return hook::pattern("40 38 38 74 08 48 FF C0 49 3B C0").count(1).get(0).get<void>(-86);
});

intptr_t CamTickCount = 0;

void* unkArgumentToTP = nullptr;
static bool gameConsoleShowing = false;
static void(*processInput_orig)(void* a1);
static void processInput(void* a1) {

	*(bool*)profilerPtr = true;
	void* vm = *(void**)luaVM;

	if (GetKeyState(VK_F8) & 0x8000)
	{
		//F8 down, open console
		executeLuaFunction(vm, !gameConsoleShowing ? "ConsoleWrapper:Show" : "ConsoleWrapper:Hide", 0, 0);

		gameConsoleShowing = !gameConsoleShowing;
	}

	if (GetKeyState(VK_F7) & 0x8000)
	{
		//F7 down, restore camera

		//filterDataSource(vm, "SendZoneDetails");
		executeLuaFunction(vm, "Ui.CameraRestore", 0, 0);
		CamTickCount = GetTickCount64();
	}

	if (GetKeyState(VK_F6) & 0x8000)
	{
		//F8 down, open console
		executeLuaFunction(vm, "GameEvents:OnPlayerRespawnRequestResponse", 0, 0);
	}

	processInput_orig(a1);
}


static void(*g_orig_TransitionClientRunState)(void* a1, int state, void* a3);
static void TransitionClientRunState(void* a1, int state, void* a3) {
	unkArgumentToTP = a1; //Set it
	g_orig_TransitionClientRunState(a1, state, a3);
}
#endif

static void(*handleInitException_orig)(void* a1, void* a2, void* a3, void* a4);
static void handleInitException(void* a1, void* a2, void* a3, void* a4) {
	__try
	{
		handleInitException_orig(a1, a2, a3, a4);
	}
	__except (EXCEPTION_EXECUTE_HANDLER)
	{
		printf_s("handleInitException excepted, caught and returned.\n");
	}
}

static void(*printProfilerCall_orig)(void* a1, char* funcName, int a3);
static void printProfilerCall(void* a1, char* funcName, int a3) {
	char msgout[256];
	sprintf(msgout, "%s - Return Address: %p\n", funcName, _ReturnAddress());
	doSomeLogging(msgout, nullptr);
	printProfilerCall_orig(a1, funcName, a3);
}

static void(*readPayLoad_orig)(void* a1, char* payLoadName, int a3);
static void readPayLoad(void* a1, char* payLoadName, int a3) {
	printf("readPayLoad - payLoadName: %s - Return Address: %p\n", payLoadName, _ReturnAddress());
	readPayLoad_orig(a1, payLoadName, a3);
}

static void(*readPayLoad2_orig)(void* a1, char* payLoadName, int a3);
static void readPayLoad2(void* a1, char* payLoadName, int a3) {
	printf("readPayLoad2 - payLoadName: %s - Return Address: %p\n", payLoadName, _ReturnAddress());
	readPayLoad2_orig(a1, payLoadName, a3);
}

struct IncomingPacket
{
	BYTE gap0[8];
	DWORD packetType;
};

static void(*handleIncomingPackets_orig)(void* thisPtr, IncomingPacket* packet, char* data, int dataLen, float time, int a6);
static void handleIncomingPackets(void* thisPtr, IncomingPacket* packet, char* data, int dataLen, float time, int a6) {
	char* packetDumpOut;
	if (packet->packetType != 60) {
		printf("\n\n\n\n\n\n\n\n\n\n");
		printf("packetType: %d - Return Address: %p\n", packet->packetType, _ReturnAddress());

		if (packet->packetType == 22 || packet->packetType == 3) { //SendZoneDetails and sendself only
			printf("Calling hexDump\n");
			hexDump("data dump for netDataBuf:", data, dataLen);
			printf("\n\n");
			hexDump("data dump for ndbAtLen:", &data[dataLen], dataLen);
		}

		printf("\n\n\n\n\n\n\n\n\n\n");
	}
	handleIncomingPackets_orig(thisPtr, packet, data, dataLen, time, a6);
}

//(void*, /*LuaVM**/ char* funcName, int, int)
static void(*executeLuaFunc_orig)(void* LuaVM, char* funcName, int a3, int a4);
static void executeLuaFuncStub(void* LuaVM, char* funcName, int a3, int a4) {
	void* retAddr = _ReturnAddress();
	if (retAddr != (void*)0x140123F56) {
		printf("executeLuaFuncStub: %s - Return Address: %p\n", funcName, retAddr);
	}
	executeLuaFunc_orig(LuaVM, funcName, a3, a4);
}

static void(*onLoginCompleteStub_orig)(void* thisPtr);
static void onLoginCompleteStub(void* thisPtr) {
	printf("onLoginCompleteStub: Return Address: %p\n", _ReturnAddress());
	onLoginCompleteStub_orig(thisPtr);
}

static void(*handleExternalPackets_orig)(void* a1, void* a2, unsigned int a3);
static void handleExternalPackets(void* a1, void* a2, unsigned int a3) {
	printf("handleExternalPackets: Return Address: %p\n", _ReturnAddress());
	handleExternalPackets_orig(a1, a2, a3);
}

class PacketHistoryEntry
{
public:
	virtual ~PacketHistoryEntry() = 0;

	unsigned char* mBuffer;
	UdpPlatformAddress mIp;
	int mPort;
	int mLen;
};

static void* (*handleExternalLoginPackets_orig)(void* a1, char* messageType, void* a3);
static void* handleExternalLoginPackets(void* a1, char* messageType, void* a3) {
	printf("handleExternalLoginPackets: messagetype: %d, Return Address: %p:\n", messageType, _ReturnAddress());
	return handleExternalLoginPackets_orig(a1, messageType, a3);
}

static void* (*parseElement_orig)(void* a1, char* element);
static void* parseElementStub(void* a1, char* element) {
	printf("parseElementStub: element: %s, Return Address: %p:\n", element, _ReturnAddress());
	return parseElement_orig(a1, element);
}

//let's get those ducks
static void* (*g_origDuckingGarbageGameLoadZone)(void* a1, void* a2, void* a3, void* a4);
static void* duckingGarbageGameLoadZone(void* a1, void* a2, void* a3, void* a4) {
	//printf("parseElementStub: element: %s, Return Address: %p:\n", element, _ReturnAddress());
	return g_origDuckingGarbageGameLoadZone(a1, a2, a3, a4);
}

static void* (*g_origOurSehFuncZoneload)(void* a1, void* a2, int a3);
static void* OurSehFuncZoneload(void* a1, void* a2, int a3) {
	//printf("parseElementStub: element: %s, Return Address: %p:\n", element, _ReturnAddress());
	void* ret = (void*)true;
	__try
	{
		ret = g_origOurSehFuncZoneload(a1, a2, a3);
	}
	__except (EXCEPTION_EXECUTE_HANDLER)
	{
		printf_s("OurSehFuncZoneload excepted, caught and returned.\n");
	}
	return ret;
}

static void* (*g_origOurSehFuncZoneload2)(void* a1, void* a2);
static void* OurSehFuncZoneload2(void* a1, void* a2) {
	//printf("parseElementStub: element: %s, Return Address: %p:\n", element, _ReturnAddress());
	void* ret = (void*)true;
	__try
	{
		ret = g_origOurSehFuncZoneload2(a1, a2);
	}
	__except (EXCEPTION_EXECUTE_HANDLER)
	{
		printf_s("OurSehFuncZoneload2 excepted, caught and returned.\n");
	}
	return ret;
}

static void* (*g_origSpeedTreeRelated)(void* a1, void* a2, intptr_t a3, intptr_t a4);
bool speedTreeRelated(void* a1, void* a2, intptr_t a3, intptr_t a4) {
	bool returnVal = true;
	__try
	{
		returnVal = g_origSpeedTreeRelated(a1, a2, a3, a4);
	}
	__except (EXCEPTION_EXECUTE_HANDLER)
	{
		printf_s("speedTreeRelated excepted, caught and returned.\n");
	}
	return returnVal;
}

static intptr_t(*g_origWaitForWorldReady)(char* a1);
intptr_t WaitForWorldReady(char* a1) {
	//*(char*)(a1 + 0x38884) = true; //ReceivedPreloadDonePacket
	intptr_t returnVal = 0;
	__try
	{
		returnVal = g_origWaitForWorldReady(a1);
	}
	__except (EXCEPTION_EXECUTE_HANDLER)
	{
		printf_s("WaitForWorldReady excepted, caught and returned.\n");
	}
	return 1;
}

static bool(*File__Open_orig)(void* a1, char* filename, int a3, int a4);
bool File__Open(void* a1, char* filename, int a3, int a4) {
	bool open = File__Open_orig(a1, filename, a3, a4);
	printf("File::Open tried to open %s - result %d\n", filename, open);
	return open;
}


static void* (*dx9InitVertex_Orig)(void* a1, int a2, int a3, void* a4);
void* dx9InitVertex(void* a1, int a2, int a3, void* a4) {
	void* address = (void*)true;
	__try
	{
		void* address = dx9InitVertex_Orig(a1, a2, a3, a4);
	}
	__except (EXCEPTION_EXECUTE_HANDLER)
	{
		printf_s("dx9InitVertex excepted, caught and returned.\n");
	}
	return address;
}

static void(*tickControllers_Orig)(void* a1, void* a2, void* a3, bool shouldProcessInput);
static void hook_tickControllers(void* a1, void* a2, void* a3, bool shouldProcessInput) {
	//a4 = false; //Always pass false to this value to tickcontrollers
	shouldProcessInput = GetTickCount64() - CamTickCount > 3000 ? true : false; //Wait 3 seconds before running this method, experimental
	tickControllers_Orig(a1, a2, a3, shouldProcessInput);
}

//Addresses
#ifndef IS_NON_ADMIN_EXE

static bool(*unkFuncStartup_orig)(char* a1, float a2);
bool unkFuncStartup(char* a1, float a2) {

	bool returnVal = unkFuncStartup_orig(a1, a2);
	*(char*)(a1 + 0x3879A) = true; //set solo mode to true
	return returnVal;
}

static void* (*AdminClient__GiveTime_orig)(char* a1);
bool AdminClient__GiveTime(char* a1) {
	//*(int*)(a1 + 0xC52A) = 13;
	int giveTimeState = *(int*)(a1 + 0x314A8);
	printf("AdminClient::GiveTime State is %d\n", giveTimeState);

	if (giveTimeState == 15) //Don't even try to connect, just jump to solo mode
		*(int*)(a1 + 0x314A8) = 13;

	void* returnVal = AdminClient__GiveTime_orig(a1);
	return returnVal;
}

#endif

void OnIntentionalCrash() {
	char buffer[512];
	sprintf(buffer, "Should have crashed, but will continue executing, return address is: %p\n", _ReturnAddress());
	MessageBox(
		NULL,
		buffer,
		"OnIntentionalCrash (0xBADF00D)",
		MB_ICONWARNING | MB_DEFBUTTON2
	);
}

static int ReturnMinus1() {
	return -1;
}
//handleIncomingPackets@<al>(__int64 a1@<rcx>, IncomingPacket *a2@<rdx>, char *a3@<r8>, int a4@<r9d>, float a5@<xmm0>, int reason?)
bool VCPatcher::Init()
{
	tryAllocConsole();
	//hook::nopVP(0x140191911, 39); //This scumbag sets rax to 0 causing a crash when loading
	//hook::return_function_vp(0x1401F6950);
	//hook::put<uint8_t>((char*)0x1404AC3FA, 0xEB); //Ignore zone did not load checks
	//Logging
	//hook::return_function_vp(0x140539670); //Server list receive thingy
	//hook::return_function_vp(0x1400301B0); //Stop crashing our game!!!
	//hook::vp::jump(0x1414BAB30, ReturnTrue);


	//hook::nopVP(0x1414BAB7C, 38); //Go die too (disable a cmp containing invalid memory)
	//hook::put<uint8_t>((char*)0x1401F7D3D, 0xEB);
	//hook::nopVP(0x1401F8BA2, 5);
	//hook::nopVP(0x1401F19C8, 5); //kill function call
	//hook::putVP<uint8_t>((char*)0x1401F19CF, 0xEB);
	//MH_CreateHook((char*)0x1414BAB30, OurSehFuncZoneload, (void**)&g_origOurSehFuncZoneload);
	//MH_CreateHook((char*)0x1401F6950, OurSehFuncZoneload2, (void**)&g_origOurSehFuncZoneload2);

	//hook::jump(0x1408D8CD0, ReturnTrue); //kill vivox entirely

	// #########################################################     Game patches         ########################################################
#if IS_NON_ADMIN_EXE
	//hook::nopVP(0x1401F7D3B, 19); //Don't call these functions that crash everything idk why - sendself related

	//Nop sendzonedetails condition statements
	//hook::nopVP(0x1401F8949, 6); //Not needed
	
#if 0
	hook::nopVP(0x1401F8993, 6); //Needed or we won't receive zone details due to some condition, I believe game checks packet length
	//hook::nopVP(0x1401F89A7, 6); //Not needed either

	//Nop for weird condition under ClientBeginZoning
#if RIP_ZONING
	//hook::nopVP(0x1401F9370, 105); 
	//hook::nopVP(0x1401F9370, 53); //Nop but leave the function alone
	//hook::nopVP(0x1401F93B8, 33);
	hook::nopVP(0x1401F9373, 6);
	hook::nopVP(0x1401F93BF, 6);
	hook::nopVP(0x1401F93D3, 6);
	//hook::nopVP(0x14049E653, 8); //Not sure what this is, crashes everything
	hook::nopVP(0x14148D6BD, 11);
#endif

	//Nuke setting spectator camera
	//hook::nopVP(0x1401F7CCD, 43);
	hook::return_function_vp(0x1408BC55B);
	//Nuke soeevent function call check
	hook::put<uint8_t>((char*)0x1402077FB, 0xEB);

	//Confirm packet
	MH_CreateHook((char*)0x140122C30, WaitForWorldReady, (void**)&g_origWaitForWorldReady); //Needs the confirm packet
	hook::return_function_vp(0x1408B4230); //crashes
	//hook::vp::jump(0x140875A00, ReturnTrue); //Process attachment group, pretend it has entries
	//hook::nopVP(0x14056F82E, 65);
#endif
	//Speedtree
	//MH_CreateHook((char*)0x14150BFE0, speedTreeRelated, (void**)&g_origSpeedTreeRelated); //needed or we crash
#if 0//ENABLED_SPEEDTREE_ANTICRASH_BAD_WORKAROUND
	hook::return_function_vp(0x14151DBA0); //Don't even try to cull trees
	hook::jump(0x14150BFE0, ReturnTrue); //Speedtree patch, always return a value regardless, needed or we crash
#endif
	//hook::nopVP(0x14150C71C, 11);
	//hook::return_function_vp(0x141513A20);

	//hook::return_function_vp(0x141907E80);

	//hook::return_function_vp(0x141520030); //no billboards for now (don't stream them)

	//hook::return_function_vp(0x14151FEA0); //kill speedtree advance :/

	//hook::return_function_vp(0x1414E52A0); //rip grass instance buffer updates I guess

	//MH_CreateHook((char*)0x141512990, dx9InitVertex, (void**)&dx9InitVertex_Orig);

	//Camera related
	//hook::return_function_vp(0x1408B4230); //Ui.RestoreCamera related?
	//hook::return_function_vp(0x1408B4740); //Camera processing thing possibly, unknown, badly decompiled unreadable
	//hook::return_function_vp(0x1449DFFF2);

	//Misc
	hook::jump(0x1400301B0, OnIntentionalCrash); //Should have crashed, but continue executing...

	//MH_CreateHook((char*)0x14020C920, hook_tickControllers, (void**)&tickControllers_Orig);
	// ###################################################     End of game patches      ############################################################

	MH_CreateHook((char*)0x140032F80, File__Open, (void**)&File__Open_orig);

	auto loc = hook::pattern("48 83 EC 38 3B 0D ? ? ? ? 4D 8B").count(1).get(0).get<char>(0);
	MH_CreateHook((char*)loc, logFuncCustom2, (void**)&logFuncCustom2_orig); //logging orig

	//Temp hook

	//Logging
	//MH_CreateHook((char*)0x140003F20, logFuncCustomCallOrig, (void**)&logFuncCustomCallOrig_orig); //hook absolutely every logging function
	//MH_CreateHook((char*)0x1400011FE, logFuncCustomCallOrig, (void**)&logFuncCustomCallOrig_orig); //Logs absolutely everything, even time

	//Other
	MH_CreateHook((char*)0x140539670, OnReceiveServer, (void**)&g_origOnReceiveServer);


	MH_CreateHook((char*)0x14019AFB0, processInput, (void**)&processInput_orig);


	MH_CreateHook((char*)0x140533A90, handleInitException, (void**)&handleInitException_orig);

	MH_CreateHook((char*)0x14127B830, readPayLoad, (void**)&readPayLoad_orig);

	MH_CreateHook((char*)0x14127C560, readPayLoad2, (void**)&readPayLoad2_orig);

	MH_CreateHook((char*)0x1401F8790, handleIncomingPackets, (void**)&handleIncomingPackets_orig);

	MH_CreateHook((char*)0x1412812C0, handleExternalPackets, (void**)&handleExternalPackets_orig);

	MH_CreateHook((char*)0x1402BA0E0, executeLuaFuncStub, (void**)&executeLuaFunc_orig);

	MH_CreateHook((char*)0x1401B7900, onLoginCompleteStub, (void**)&onLoginCompleteStub_orig);

	MH_CreateHook((char*)0x141280520, handleExternalLoginPackets, (void**)&handleExternalLoginPackets_orig);

	//MH_CreateHook((char*)0x1400039F0, parseElementStub, (void**)&parseElement_orig);

	//MH_CreateHook((char*)0x1400CBC90, printProfilerCall, (void**)&printProfilerCall_orig); //Crashes everything when the console is invoked, so disable
	//hook::return_function_vp(0x1402BFA80); //Prevent a crash, tmpdbg

	//140031570

	//MH_CreateHook((char*)0x1409E7D34, _report_gsfailure, (void**)&_report_gsfailure_orig); //exception handler around gsfailure

	//MH_CreateHook((char*)0x14034BFA0, logFuncCustom1, (void**)&logFuncCustom1_orig); //Logs clock timeeee
	//MH_CreateHook((char*)0x1402933B0, logFuncCustom4, (void**)&logFuncCustom4_orig); //logs clock time amongst other things

	//Transition related
	//loc = hook::pattern("48 89 5C 24 ? 57 48 83 EC 20 83 B9 ? ? ? ? ? 8B").count(1).get(0).get<char>(0);
	//MH_CreateHook((char*)loc, TransitionClientRunState, (void**)&g_orig_TransitionClientRunState); //We need the second argument to call _doTeleport

	//MH_CreateHook((char*)0x1404CDAE0, GetShutdownReasonString, (void**)&g_origGetShutdownReasonString);

	//loc = hook::pattern("E8 ? ? ? ? 4C 8B C8 41 83 CE FF 44 89 74 24").count(1).get(0).get<char>(-0x81);
	//g_origLoadConfigFile = (decltype(g_origLoadConfigFile))((loc));
	//MH_CreateHook((char*)0x1404AB950, WaitForWorldReady, (void**)&g_origWaitForWorldReady);
#else
	//auto loc = hook::pattern("48 83 EC 38 3B 0D ? ? ? ? 4D 8B").count(1).get(0).get<char>(0);
	MH_CreateHook((char*)/*0x1405F7A30*/0x1400834B5, logFuncCustom2, (void**)&logFuncCustom2_orig); //logging orig
	MH_CreateHook((char*)0x140B25EE0, unkFuncStartup, (void**)&unkFuncStartup_orig);
	MH_CreateHook((char*)0x14028C010, AdminClient__GiveTime, (void**)&AdminClient__GiveTime_orig);
	//hook::return_function_vp(0x14122A5A0); //Don't call this, it crashes
	//hook::return_function_vp(0x140B22510); //Don't do launchpad checks?
	//MH_CreateHook((char*)0x140074636, logFuncCustom4, (void**)&logFuncCustom4_orig);
	hook::nopVP(0x140B5702F, 34); //nop these instruction call that crashes everything
	hook::nopVP(0x140B2269B, 12);
#endif

#if IS_NON_ADMIN_EXE
	//Net Routing
	hook::iat("wsock32.dll", CfxSend, 19);

	hook::iat("wsock32.dll", CfxSendTo, 20);

	//hook::iat("wsock32.dll", CfxRecvFrom, 17);
	hook::iat("wsock32.dll", CfxBind, 2);
	g_oldSelect = hook::iat("wsock32.dll", CfxSelect, 18);
	hook::iat("wsock32.dll", CfxGetSockName, 6);
	hook::iat("wsock32.dll", CfxWSAStartup, 115);
#endif

	MH_CreateHookApi(L"kernel32.dll", "ExitProcess", ExitProcessReplacement, nullptr);

	MH_EnableHook(MH_ALL_HOOKS);

	return true;
}

/*

static char*(*g_origGetShutdownReasonString)(int index);
static char* GetShutdownReasonString(int index)
{
return g_origGetShutdownReasonString(index);
}

1404CDAE0

*/

bool VCPatcher::PatchResolution(D3DPRESENT_PARAMETERS* pPresentationParameters)
{
	pPresentationParameters->Windowed = true;
	pPresentationParameters->Flags = 0;
	pPresentationParameters->FullScreen_RefreshRateInHz = 0;
	//pPresentationParameters->FullScreen_PresentationInterval = 0;

	SetWindowPos(pPresentationParameters->hDeviceWindow, HWND_NOTOPMOST, 0, 0, pPresentationParameters->BackBufferWidth, pPresentationParameters->BackBufferHeight, SWP_SHOWWINDOW);
	SetWindowLong(pPresentationParameters->hDeviceWindow, GWL_STYLE, WS_POPUP | WS_CAPTION | WS_MINIMIZEBOX | WS_SYSMENU | WS_VISIBLE);
	return true;
}

void hexDump(const char* desc, const void* addr, const int len) {
	int i;
	unsigned char buff[17];
	const unsigned char* pc = (const unsigned char*)addr;

	// Output description if given.

	if (desc != NULL)
		printf("%s:\n", desc);

	// Length checks.

	if (len == 0) {
		printf("  ZERO LENGTH\n");
		return;
	}
	else if (len < 0) {
		printf("  NEGATIVE LENGTH: %d\n", len);
		return;
	}

	// Process every byte in the data.

	for (i = 0; i < len; i++) {
		// Multiple of 16 means new line (with line offset).

		if ((i % 16) == 0) {
			// Don't print ASCII buffer for the "zeroth" line.

			if (i != 0)
				printf("  %s\n", buff);

			// Output the offset.

			printf("  %04x ", i);
		}

		// Now the hex code for the specific character.
		printf(" %02x", pc[i]);

		// And buffer a printable ASCII character for later.

		if ((pc[i] < 0x20) || (pc[i] > 0x7e)) // isprint() may be better.
			buff[i % 16] = '.';
		else
			buff[i % 16] = pc[i];
		buff[(i % 16) + 1] = '\0';
	}

	// Pad out last line if not exactly 16 characters.

	while ((i % 16) != 0) {
		printf("   ");
		i++;
	}

	// And print the final ASCII buffer.

	printf("  %s\n", buff);
}

static struct MhInit
{
	MhInit()
	{
		MH_Initialize();
	}
} mhInit;